import * as path from 'path';

export const UPLOAD_PATH = path.join(process.cwd(), 'uploads'); 